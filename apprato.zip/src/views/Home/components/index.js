export { default as Customization } from "./Customization";
export { default as Hero } from "./Hero";
export { default as Experts } from "./Experts";
export { default as Plans } from "./Plans";
export { default as Services } from "./Services";
export { default as Carouselview } from "./Carouselview";
export { default as Consultants } from "./Consultants";
export { default as Readysetcode } from "./Readysetcode";
export { default as Partners } from "./Partners";
export { default as Pricings } from "./Pricings";
export { default as ServicesMobile } from "./ServicesMobile";
export { default as MessageForm } from "./MessageForm";
export { default as Work } from "./Work";
export {default as Insights} from "./Insights"
