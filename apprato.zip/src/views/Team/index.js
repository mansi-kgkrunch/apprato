export { default } from './Team';
