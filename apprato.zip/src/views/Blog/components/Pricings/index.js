export { default } from './Pricings';
