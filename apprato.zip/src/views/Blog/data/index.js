export const sas2 = [
  {
    logo: '/images/partnerlogos/Emersys.svg',
    name: 'Emersys',
  },
  {
    logo: '/images/partnerlogos/DotDigital.svg',
    name: 'DotDigital',
  },
  {
    logo: '/images/partnerlogos/Twillio.svg',
    name: 'Twillio',
  },
];
export const sas1 = [
  {
    logo: '/images/partnerlogos/Magento 2.svg',
    name: 'Magento 2',
  },
  {
    logo: '/images/partnerlogos/AWS.svg',
    name: 'AWS',
  },
  {
    logo: '/images/partnerlogos/Pub Nub.svg',
    name: 'Pub Nub',
  },
];
export const sas3 = [
  {
    logo: '/images/partnerlogos/Apparel21.svg',
    name: 'Apparel21',
  },
  {
    logo: '/images/partnerlogos/Bunchball.svg',
    name: 'Bunchball',
  },
  {
    logo: '/images/partnerlogos/Comestri.svg',
    name: 'Comestri',
  },
  {
    logo: '/images/partnerlogos/Zendesk.svg',
    name: 'Zendesk',
  },
  {
    logo: '/images/partnerlogos/Hubspot.svg',
    name: 'Hubspot',
  },
  {
    logo: '/images/partnerlogos/MailChimp.svg',
    name: 'MailChimp',
  },
];
export const sas4 = [
  {
    logo: '/images/partnerlogos/Kount.svg',
    name: 'Kount',
  },
  {
    logo: '/images/partnerlogos/CyberSource.svg',
    name: 'CyberSource',
  },
  {
    logo: '/images/partnerlogos/Pay Pal.svg',
    name: 'Pay Pal',
  },
  {
    logo: '/images/partnerlogos/Stripe.svg',
    name: 'Stripe',
  },
  {
    logo: '/images/partnerlogos/Zip.svg',
    name: 'Zip',
  },
  {
    logo: '/images/partnerlogos/Braintreee.svg',
    name: 'Braintreee',
  },
];
export const sas5 = [
  {
    logo: '/images/partnerlogos/Australia Post.svg',
    name: 'Australia Post',
  },
  {
    logo: '/images/partnerlogos/Startrack.svg',
    name: 'Startrack',
  },
];
