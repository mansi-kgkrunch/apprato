export { default } from "./Strategy";
