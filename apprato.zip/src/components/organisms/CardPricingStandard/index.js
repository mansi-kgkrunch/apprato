export { default } from './CardPricingStandard';
