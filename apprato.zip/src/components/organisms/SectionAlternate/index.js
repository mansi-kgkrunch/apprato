export { default } from './SectionAlternate';
