export { default } from './Icon';
