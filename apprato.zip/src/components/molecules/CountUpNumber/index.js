export { default } from './CountUpNumber';
